<section id="first">
   <div class="container">
      <h1>
         ПОВЫШЕНИЕ<br>КВАЛИФИКАЦИИ СПЕЦИАЛИСТОВ<br>И ОБУЧЕНИЕ СТУДЕНТОВ<span>по системе доктора Реутова</span>
      </h1>
      <button onclick="location.href='{{ route('application.create.guest') }}'">Записаться на обучение</button>
      <ul class="first__list row">
         <li class="first__item first__item_l col-xl-5 col-lg-8 col-md-10 col-sm-12">
            <div>
               15
            </div>
            <p>
            обучающих <br>программ
            </p>
         </li>
         <li class="first__item first__item_r col-xl-5 col-lg-8 col-md-10 col-sm-12">
            <div>
               94
            </div>
            <p>
            практических занятия <br>в формате тестов
            </p>
         </li>
      </ul>
   </div>
</section>
