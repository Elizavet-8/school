<footer>
    <div style="padding-right: 30px; padding-left: 30px" class="container">
       <div class="row footer__logo">
          <div class="logotip col-6">
             <p>Система дистанционного обучения Росвуз</p>
          </div>
          <div class="col-6">
             <a class="footer__link footer__link-active">
                school@rosvuz.ru
             </a>
          </div>

       </div>
       <div class="row">
          <a href="#" class="footer__links">
             Политика конфидициальности
          </a>
          <a href="#" class="footer__links">
             Правила пользования сайтом
          </a>
          <p class="footer__prg">
             Все права защищены © 2021
          </p>
          <a class="footer__link">
             school@rosvuz.ru
          </a>
       </div>
    </div>
 </footer>
